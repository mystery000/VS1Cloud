

/**
 * This variable is going to be used to replace 
 * the default empty currency in case if there is not currency filled
 */
 export const currencySymbolEmpty = "/";