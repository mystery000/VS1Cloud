export default class HeaderCard {
  constructor({ key, position, employeeId }) {
    this.key = key;
    this.position = position;
    this.employeeId = employeeId;
  }
}
