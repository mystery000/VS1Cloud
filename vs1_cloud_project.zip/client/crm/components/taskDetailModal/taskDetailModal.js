import { CRMService } from '../../crm-service';
let crmService = new CRMService();

Template.taskDetailModal.onCreated(function () {
});

Template.taskDetailModal.onRendered(function () {
});

Template.taskDetailModal.events({

});

Template.taskDetailModal.helpers({
});
