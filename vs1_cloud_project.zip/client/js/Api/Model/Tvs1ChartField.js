export default class Tvs1ChartField {
  constructor({
    Active,
    ChartGroup,
    ChartName,
    Gloablref,
    GlobalRef,
    ID,
    ISEmpty,
    KeyStringFieldName,
    KeyValue,
    MsTimeStamp,
    MsUpdateSiteCode,
    Recno
  }) {
    this.Active = Active;
    this.ChartGroup = ChartGroup;
    this.ChartName = ChartName;
    this.GlobalRef = GlobalRef;
    this.gloablref = Gloablref;
    this.ID = ID;
    this.ISEmpty = ISEmpty;
    this.KeyStringFieldName = KeyStringFieldName;
    this.KeyValue = KeyValue;
    this.MsTimeStamp = MsTimeStamp;
    this.MsUpdateSiteCode = MsUpdateSiteCode;
    this.Recno = Recno;
  }
}
