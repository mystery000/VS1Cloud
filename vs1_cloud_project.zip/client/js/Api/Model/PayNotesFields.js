export default class PayNotesFields {
    constructor({
        EmployeeID,
        ID,
        Notes,
        CreatedAt,
        UserID,
        UserName,
        Active
    }){
        this.EmployeeID = EmployeeID;
        this.ID = ID;
        this.Notes = Notes;
        this.CreatedAt = CreatedAt;
        this.UserID = UserID;
        this.UserName = UserName;
        this.Active = Active;
    }
}
  
  