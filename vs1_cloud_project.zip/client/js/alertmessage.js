Bert.defaults = {
hideDelay: 2500,
style: 'fixed-top',
type: 'default'
};
